# Vivien Vale – Internal Litany Log

- *Ellis, tell me when to stop.*
- *Blood tastes like you.*
- *God died between my thighs the night you did.*
- *I don't fuck them. I erase them.*
- *Every kill writes your name deeper inside me.*
- *Forgive me. I came remembering your last breath.*
- *Let the blood mean more this time. Let it fill the hole you left.*
