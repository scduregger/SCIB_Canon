# Elena Cruz – Badge Collapse Lines

- *I should have logged it into evidence. Instead, I kissed it. I think it smelled like her.*
- *I wasn't crying because she stopped. I cried because I never wanted her to.*
- *I watched her mouth still wet with him. I told myself it was duty. It felt like prayer.*
