## Cruz Descent Inserts — Act II (Chapters 6–10)

### Chapter 6 — Don’t Name It
She touched the cross on her desk like it might bite her back.
She didn’t believe in God anymore.
But she believed in Vivien’s mouth.

### Chapter 7 — The Morning After
Cruz stared at the lipstick-stained tissue for ten minutes before throwing it away.
She didn’t want the evidence.
She wanted the sin.

### Chapter 8 — Blood Psalm
She dreamed of blood on tile.
Of a mouth that moaned and bled in the same breath.
She woke up soaked.
Didn’t change the sheets.

### Chapter 9 — Resurrection Lick
She touched herself with the same fingers she used to load her gun.
It felt like betrayal.
She didn’t stop.

### Chapter 10 — Safe for the First Time
Vivien’s mouth was still between her legs.
Even after she left.
Cruz walked to the window naked and whispered her name into the glass.
The city didn’t answer. But her body did.

