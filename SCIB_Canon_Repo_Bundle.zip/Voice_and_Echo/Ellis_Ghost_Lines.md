# Ellis Monroe — Ghost Echo Line Archive

These lines should appear mid-orgasm, post-kill, or during emotional fracture.

- *You always come harder when you cry.*
- *Don’t forget how I touched you.*
- *I died inside you. You made it holy.*
- *You moaned my name as I bled out. That’s the only heaven I believe in.*
- *Your cunt still tastes like our last night.*
- *Every time you come, I rise a little.*
- *He’ll never kiss your knees after you squirt.*
- *You carry me in your hips.*
- *You made me a ghost worth haunting.*
- *I see you when you fake it. I see you when you don’t.*
- *This isn’t guilt. It’s resurrection.*
- *Every kill is a love letter to the moment I died.*
- *When you touch her, I feel it too.*
- *You never stopped loving me. You just fuck through it now.*
- *Blood never scared you. That’s why I stayed.*
