# SCIB Ghost Line Archive

## “A flicker in her cunt like memory...”
- **Type:** Saved for Later
- **Intended Reprise:** Vivien’s grief-sex spiral or deep ritual chapter
- **Emotion/Echo:** Ellis haunting / grief erotics
- **Notes:** Originally from Prologue. Can resurface during second major Vivien ritual or hallucinated flashback.

## “She always gave the scene a moment...”
- **Type:** Scene Echo
- **Intended Reprise:** Cruz in reversed power or ritual setting
- **Emotion/Echo:** Sacred gaze / transformation
- **Notes:** May resurface when Cruz observes a scene with Vivien's logic—especially at turning point.

## “It wasn’t evidence. It was invitation.”
- **Type:** Reprise Target
- **Intended Reprise:** Second lipstick-marked victim or Cruz putting it on herself
- **Emotion/Echo:** Sexual permission / submission
- **Notes:** Strong echo candidate for Cruz’s sexual turning point, possibly Chapter 10 or 15.

## “She’s not gonna say anything we can use. But I’ll let you have your dance.”
- **Type:** Red Herring Thread
- **Intended Reprise:** Later Gallagher dialogue or precinct echo
- **Emotion/Echo:** Power / suspicion / mockery
- **Notes:** Sets up Gallagher as unreliable narrator or partial conspirator. Could echo just before his elimination.

## “The kind of woman who came wrapped in silk and suspicion.”
- **Type:** Voiceover Flashback
- **Intended Reprise:** Cruz narration or dream reflection
- **Emotion/Echo:** Longing / surrender
- **Notes:** Poetic language best suited to stylized voiceover or final realization scene.
