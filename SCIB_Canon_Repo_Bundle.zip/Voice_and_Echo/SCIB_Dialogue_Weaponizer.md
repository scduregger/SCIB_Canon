# SCIB Dialogue Weaponizer Sheet

## 🩸 Vivien Vale – Killer Aphorisms
- *Say his name.*
- *Now it’s art.*
- *This is for Ellis.*
- *You don’t get to finish without gratitude.*
- *I’m not your punishment. I’m your prayer.*
- *That wasn’t a fuck—it was an exorcism.*
- *Ellis still lives in my cunt. You just visited.*
- *Even your death can’t make me come like he did.*
- *My orgasms don’t forgive. They remember.*

## 💋 Cruz – Whispered Confessions
- *Don’t stop.*
- *I’ve never let anyone see me like this.*
- *I want to be kept.*
- *Touch me like I’m not a cop.*
- *I don’t care if it’s a sin. I need you.*
- *I’m not here to arrest you. I’m here to confess.*
- *Please… I don’t want to be strong right now.*
- *When you rimmed me… I saw God. And I didn’t ask for forgiveness.*
- *I came thinking about you killing him. What does that make me?*

## 👻 Ellis – Ghost Echoes
- *You always come harder when you cry.*
- *I died inside you. You made it holy.*
- *Every kill is a love letter to the moment I died.*
- *Every time you come, I rise a little.*
- *You never stopped loving me. You just fuck through it now.*
- *When you touch her, I feel it too.*
