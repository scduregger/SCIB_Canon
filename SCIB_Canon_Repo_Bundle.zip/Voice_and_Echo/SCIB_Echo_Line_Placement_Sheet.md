# Echo Line Placement Tracker

## She forgave me with her thighs.
- **Chapter**: Chapter 11 — The Woman She’s Chasing
- **Context**: Post-orgasm aftermath; Cruz can't look at Vivien but lets her stay

## It wasn’t evidence. It was invitation.
- **Chapter**: Chapter 2 — Her Mouth Was a Clue
- **Context**: Cruz reviews the crime scene photo with lipstick mark; realization flickers

## You always came harder when you cried.
- **Chapter**: Chapter 9 — Resurrection Lick
- **Context**: Vivien hears Ellis’s voice mid-orgasm as she breaks during grief-masturbation

