---

## 🩸 RITUAL KILL SCENE INDEX — VIVIEN VALE

| Kill # | Chapter    | Victim                | Method                                     | Falco Connection                        | Cruz Emotional Turn                 |
| ------ | ---------- | --------------------- | ------------------------------------------ | --------------------------------------- | ----------------------------------- |
| 1      | Prologue   | **Roy Marsh**         | Riding + clit play → throat slit at climax | Paid to stay silent on Ellis’s death    | First Lustmark — crime awakens her  |
| 2      | Chapter 3  | **Daniel Carrow**     | Facefucking + mounting → blade to heart    | Ritual fixer + blackmail handler        | Steals Polaroid, lies to forensics  |
| 3      | Chapter 4  | **Father Jared Knox** | Pegged to climax → scarf strangulation     | Led Falco’s “Redemption Room”           | Touches harness too long. Aroused   |
| 4      | Chapter 11 | **Victor LaRue**      | Rode to squirt → throat slit mid-aftermath | Councilman. Resembled Ellis. Bought off | Steals scarf. Masturbates with it   |
| 5      | Chapter 13 | **Tony Marchello**    | Rimmed + sucked → anal blade + throat cut  | Mob node. Named Falco in death          | Silent accomplice. Does not report  |
| 6      | Chapter 17 | **Dominic Falco**     | Ridden to climax → mutual stabbing         | Master of the sex ring. Killed Ellis    | Final collapse. Badge becomes relic |

---

## 🔥 RITUAL COMPLETION THREADS

* **Every kill mirrors Ellis’s death**: climax + collapse + curse.
* **Vivien never truly aroused** — climax = ghost trigger.
* **Falco ring fully exposed**: each man part of the corruption machine.
* **Cruz doesn’t solve it. She absorbs it.**

---

## 🔪 WEAPON + FLUID TRACKER

| Kill # | Weapon       | Key Fluid(s)   | Symbol                      |
| ------ | ------------ | -------------- | --------------------------- |
| 1      | Knife        | Blood + Cum    | Psalm initiation            |
| 2      | Knife        | Cum + Spit     | Ritual exposure             |
| 3      | Silk Scarf   | Cum + Sweat    | Redemption turned execution |
| 4      | Knife        | Squirt + Blood | Memory mercy revoked        |
| 5      | Switchblade  | Blood + Saliva | Communion through violence  |
| 6      | Knife (both) | All fluids     | Holy martyrdom              |

---

## 🕯️ SECOND DRAFT MASTER CHAPTER INDEX — KILL SCENE ALIGNMENT

| Chapter    | Title                    | Kill? | Victim            | Status    |
| ---------- | ------------------------ | ----- | ----------------- | --------- |
| Prologue   | Psalm of the First Cut   | ✅     | Roy Marsh         | Confirmed |
| Chapter 3  | Sacred Disruption        | ✅     | Daniel Carrow     | Confirmed |
| Chapter 4  | The Harness and the Halo | ✅     | Father Jared Knox | Confirmed |
| Chapter 11 | The Woman She’s Chasing  | ✅     | Victor LaRue      | Confirmed |
| Chapter 13 | The Bloody Communion     | ✅     | Tony Marchello    | Confirmed |
| Chapter 17 | The Body Is the Evidence | ✅     | Dominic Falco     | Confirmed |

---